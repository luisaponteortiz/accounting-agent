# Independent reverification: C-01–C-06 and Batch 2

Act as an independent senior accounting architect, accounting-controls reviewer, and technical verification engineer for Accounting Agent OS. Review the attached `FABLE_CORRECTIONS_AND_BATCH_2_REVIEW_BUNDLE.zip` and return an evidence-based acceptance decision plus prioritized, implementable corrections for Codex.

The product is a general, reusable Accounting Agent OS covering General Ledger, AP, AR, Banking & Reconciliation, Month-End Close, and Financial Reporting/Analysis. Bird Bowl is the first client implementation. The executable demonstration is deliberately limited; it does not define the whole product or establish full-cycle functionality.

Assess whether shared execution, knowledge, evidence, authority, and client configuration can support those six areas incrementally without mixing client data. Keep executive, sales, marketing, and other non-accounting agents outside this review.

Your assignment is to independently verify **C-01 through C-06 and Batch 2 tickets T-09 through T-19**, including the additions in your corrective review. Treat Codex's reports, passing gate labels, and recorded logs as claims to test. Inspect actual source, assertions, migrations, and behavior. Look for counterexamples and control bypasses, not merely agreement with the supplied fixtures.

Use fictional data and temporary databases only. Review and create verification artifacts; do not implement application fixes, change acceptance criteria to make tests pass, activate deferred capabilities, connect live systems, call paid models/services, post accounting entries, execute payments, deploy, or grant real operating authority. Preserve original review inputs and frozen archives. Put any test-only adaptations or probes in separate files and explain them.

## 1. Establish the evidence and review criteria

Extract the outer archive and work from its project root. Use disposable working copies and retain an untouched extraction for comparison. The nested ZIPs are historical checkpoints; do not confuse their source with the current outer source.

First read:

- `exports/FABLE_BATCH_1_VERIFICATION/FABLE_BATCH_1_VERIFICATION.md`
- `exports/FABLE_BATCH_1_VERIFICATION/FABLE_BATCH_1_1_CORRECTIONS.json`
- `exports/FABLE_BATCH_1_VERIFICATION/batch1_verification_probes.py`
- `exports/FABLE_BATCH_1_VERIFICATION/batch1_probe_output.txt`
- `review/FABLE_ARCHITECTURE_REVIEW.md`, especially the findings and section 9 readiness gates
- `review/FABLE_IMPLEMENTATION_BACKLOG.json`, including Batch 2 dependencies, acceptance criteria, and completion gate
- `review/FABLE_VALIDATION_CASES.json`, the maintained runners/probes, and the original scripts in `review/original/`
- `docs/FABLE_CORRECTION_REVERIFY.md`, `docs/CORRECTIVE_REPORT.md`, and `docs/BATCH_2_REPORT.md`
- `PROGRESS.md`, `DECISIONS.md`, `docs/ARCHITECTURE.md`, `docs/CAPABILITY_CONTRACTS.md`, and `docs/CONNECTION_READINESS.md`

Then inspect runtime source in `accounting_agent/`, tests in `tests/`, and the scripts used to generate evidence. Use `FABLE_ACCOUNTING_HANDOFF.md` for broader architecture and known client context, respecting its current-checkpoint notice. Do not invent Bird Bowl's actual accounts, mappings, systems, financial information, or policies.

Verify `REVIEW_MANIFEST.json` against the archive contents. Check the four independent verification inputs against `docs/batch2/input-checksums.json` and the frozen corrective archive. Inspect `docs/batch2/source-and-tests.patch` and `changed-files.json`; their baseline is the included `exports/FABLE_BATCH_1_REVIEW_BUNDLE.zip`. Confirm that the diff and inventory represent the actual source. Hash consistency alone does not prove correct accounting or controls.

## 2. Distinguish the historical correction gate from current behavior

Codex claims C-01–C-06 were implemented in your prescribed order—C-05, C-06, C-02, C-04, C-03, C-01—and passed before T-12, T-14, or T-18 began. The frozen corrective source is in `exports/FABLE_CORRECTIVE_C01_C06_REVIEW_BUNDLE.zip`.

Run:

```sh
python3 scripts/verify_corrective_checkpoint.py
```

Inspect that wrapper and, if needed, extract the frozen archive yourself into a separate temporary directory. From that checkpoint's root, the direct command is:

```sh
python3 exports/FABLE_BATCH_1_VERIFICATION/batch1_verification_probes.py .
```

Verify N01–N07 individually report OK and the other required corrective checks remain satisfied. The historical checkpoint intentionally retains then-deferred Batch 2 failures; distinguish those from regressions. Evaluate the supplied sequencing evidence without claiming the archive alone proves every implementation step's chronology.

**Passing this historical checkpoint does not establish that the current code passes.** Current Batch 2 registration is proposed-only and requires explicit grants, independent profile/mandate approval, structured statements, source ordering metadata, and lock acknowledgements. The original script assumes older setup contracts. Codex therefore supplies `review/batch2_verification_probes.py` for the current API.

Independently compare the original and maintained probes. Decide whether each adaptation preserves the original accounting invariant or weakens the test. A compatibility explanation is not an automatic exemption from a failed control. Carry the original N01–N07 failure scenarios into the current API with explicit, auditable setup; do not silently auto-approve policy, supply missing authority, or repair an adversarial input. Add your own probes wherever the maintained harness is weak. In particular, evaluate each journal control separately and verify alias-normalization visibility rather than accepting a NOTE label as evidence of compliance.

## 3. Execute the current gates

From the outer bundle's project root, run:

```sh
make test
make check
make batch2-gate
```

The individual current verification commands are:

```sh
python3 review/run_fable_validation_cases.py . review/FABLE_VALIDATION_CASES.json --batch2-gate
python3 review/batch2_verification_probes.py .
python3 scripts/synthetic_month.py
```

If make is unavailable, run `python3 -m unittest discover -s tests -v` and `python3 scripts/check.py`, followed by all three individual commands above. `make batch2-gate` regenerates `docs/batch2/final-validation.json`; retain the delivered report separately and distinguish it from your rerun output.

Record Python/SQLite versions, exact commands, exit codes, stdout/stderr, and environment restrictions in your own output files. Tests require Python 3.9+ and temporary loopback access for HTTP integration. If your environment cannot execute a check, report NOT_RUN with the precise limitation; separate static inspection from execution and supplied logs from independently reproduced results. Do not infer PASS from an inability to run.

The developer claims **111 passing tests**, retaining all **41 original platform/HTTP methods**, and **60 reviewer cases: 29 PASS, 10 FIXED, 21 DEFERRED-OK**, with no FAIL, UNEXPECTED, KNOWN-FAIL, or DEFERRED-LEAK. Reproduce or correct these counts. Check that retained method names also retain meaningful assertions; inspect every deliberate contract/fixture change. Do not require a repaired defect to remain an expected failure.

Report every one of the 60 case IDs separately. All ten original fail-until-fix cases must be FIXED for Batch 2. FV-CL04 is now executable. Examine FV-C13 supersession, FV-J05/J07 period contracts, receipt policy-unset codes, journal support bindings, and the fictional statement adapter for justified changes versus weakened evidence. The adapter must not turn a defective input into a passing one or run as accounting intake logic. The 21 genuinely deferred capability cases must remain unavailable/refused; do not require their future business outcomes to execute. An unimplemented assigned Batch 2 control is a failure, not a newly invented deferral.

## 4. Verify the corrective invariants on current source

Pair negative probes with valid positive controls. Confirm a refusal comes from the intended invariant rather than missing grants, incomplete statement evidence, or unrelated blockers. An implementation that denies every approval has not demonstrated independent review or a functioning workflow.

- **C-01 / N02:** A revised source moving out of a locked period, including its supporting evidence, enters no destination population until the origin reopens. Verify quarantine reason, both-period audit evidence, re-evaluation on reopen, stale origin approval, and at most one current governing artifact for the source across periods. Include replays and recurring runs.
- **C-02 / N01:** Approve, reject, revoke, resolve_approve, and resolve_reject all refuse with PERIOD_LOCKED/409 under lock and preserve protected decisions. Verify audited authorized reopen is required.
- **C-03 / N03:** Identical accounting inputs/versions/output reuse the governing artifact across enqueuers and mandate issuers, preserving rejection/approval. Contributor provenance appends outside content identity. Newly linked contributors lose review rights. Legacy bytes and decisions remain unchanged.
- **C-04 / N04–N05:** Cosmetic revisions cannot erase historical preparation/configuration authorship. Verify all relevant evidence-version suppliers, applied-rule proposers/approvers, and chart/entity/book configuration lineage. Under T-14, another item's receipt must not bar an otherwise independent reviewer of this item. Do not demand the superseded population-wide interim rule remain in force.
- **C-05 / N06:** NFKC/casefold preserves Unicode letter, number, and mark categories, including combining marks; no accent/mark stripping. Test the original script pairs and end-to-end unknown/ambiguous vendor holds, plus empty aliases and normalization collisions.
- **C-06 / N07:** Actor.kind has no human default. Omitted kind fails; explicit service actors cannot acquire human review/approval/disposition/finalization authority through their names, roles, or transport inputs.

## 5. Verify every Batch 2 ticket and its added criteria

Follow the assigned dependency order: **T-09, T-11, T-12, T-10, T-13, T-14, T-15, T-16, T-17, T-18, T-19**. Use the JSON acceptance criteria as the full checklist, including the corrective review's additions. Prioritize these adversarial checks:

- **T-09:** Proposed profiles/rules remain inert; independent granted humans activate them. Effective dates, supersession, item scope, normalized-alias presentation, and configuration authorship are real controls. Future-period and unrelated close-rule changes preserve earlier card/journal approvals and applicable mandates. Required review policy uses the item's effective date. Fixture approval/grant helpers must not expose a transport bypass.
- **T-11:** Required client facts hold missing-fact client samples. Explanatory synthetic waivers remain explicit, exported, and confined to fictional demonstrations.
- **T-12:** Older/conflicting as_of delivery and old packet replay cannot regress accepted heads. Test tombstones with unchanged content, supersession, approved-source changes, evidence received before period opening, identical-content rebinding, cross-month receipts, and quarantine visibility to close readiness.
- **T-10:** Mandates require independent approval, bind relevant policies and explicit target-period/freshness rules, expire, and suspend on relevant policy changes. Awaiting-evidence occurrences recover without bypassing authority or consuming the only usable execution attempt. Test concurrent ticks and restart behavior.
- **T-13:** Statement balances, activity-specific signed totals, line identities/counts, prior-period continuity, provenance, and excluded population are checked. Same-count/same-net population swaps, foreign rows, and purchase/payment offsetting must not give false completeness. Identify limits when authoritative evidence or cycle policy is absent.
- **T-14:** Closed-vocabulary, evidence-bound dispositions persist, re-prepare, and require separate review. Test distinct receipts/duplicates, exact split sums, service denial, revocation, proposed-rule scope, historical item contributors, and dependency blockers. External referral or duplicate exclusion must not manufacture clean approval or silently suppress ledger effect.
- **T-15:** One shared validator governs scoped entity/book/period/currency/lines/origin/not_posted entries. Verify signed expense/credit/settlement/transfer effects, allocations, reproducible account impact, and duplicate origin claims across modules. A balanced proposal alone does not establish correct recognition.
- **T-16:** Test unbound/wrong-type journal support, duplicate journals, and zero-net-effect entries independently, including dimensions and both affected items.
- **T-17:** Approved receipt parameters govern behavior; unset policy stays explicit and proposed rules have no effect. Test both sides of date/amount boundaries and multiple-document/vendor/substitution behavior without inventing tolerances.
- **T-18:** Finalization requires independent granted authority, exact immutable content and explicit carried-issue acknowledgement. Stale/disputed work and package-level controls cannot be cleared by acknowledgement. Later source/policy/decision changes leave frozen bytes unchanged and create visible events. Verify lock preconditions, mistaken-revoke recovery, and bounded resolved disputes.
- **T-19:** Close uses period-bound governing outcomes, review/exception/quarantine status, and typed evidence. A label-only document cannot complete deferred reconciliation/tieout work. External/final-close holds remain. Test the in-flight-preparation concurrency race and verify waiting/refresh does not silently adopt changed sources or policy.

Also challenge scope isolation, immutable migrations/history, leases/restart/concurrency, rejected-decision preservation, UI/API authority boundaries, and documentation accuracy across these controls. Distinguish accepted local-demo limitations from defects that violate the claimed local controls.

## 6. Judge the full-month and G0 evidence

Independently drive the teaching fixture through service operations, without database edits, discarded evidence, fabricated client policy, or weakened blockers. Codex claims nine card approvals plus two journal approvals, two held card items with explicit external-referral dispositions, two finalized preparation packages, a locked November, and unchanged first-client records when a second client executes December work.

Specifically examine TX-007's pending hold, TX-011's currency hold, and October TX-008 remaining quarantined and acknowledged. Decide whether those treatments actually meet your original full-month/G0 criteria; do not assume the walkthrough's assertions settle that question. Recalculate proposed entry impact independently and inspect the full disposition/approval lineage.

Give separate judgments on correction acceptance, Batch 2 acceptance, and whether the software evidence satisfies G0's technical criteria. Human G0 acceptance remains a separate decision. No result opens G1–G4 or authorizes real samples, connections, posting, payments, external close, hosting, or production operation. Keep AP/AR, full reconciliation, reporting, and other assigned Batch 3/deferred work outside implementation scope; flag an in-scope bypass even if it touches a deferred boundary.

## 7. Return artifacts Codex can implement from

Return these files together:

1. **`FABLE_REVERIFICATION_REPORT.md`** — Lead with separate PASS/FAIL/NOT_VERIFIED decisions for the historical corrective checkpoint, current C-01–C-06, Batch 2, and G0 technical criteria. Include per-ticket/per-criterion evidence, executed versus inspected checks, harness/fixture adaptation judgments, accounting impact, remaining limitations, and the recommended next implementation boundary.
2. **`FABLE_REVERIFICATION_RESULTS.json`** — Machine-readable results for C-01–C-06, N01–N07 and relevant additional probes, every T-09–T-19 acceptance criterion, all 60 validation case IDs, the full-month/isolation criteria, and G0. Use explicit PASS/FAIL/NOT_RUN/DEFERRED where appropriate, preserving raw runner statuses separately. Include commands, exit codes, source references, and evidence-file links. Missing evidence must not become PASS.
3. **`FABLE_REVERIFICATION_CORRECTIONS.json`** — Prioritized confirmed defects for Codex: stable ID, P0/P1/P2/P3, affected C/T requirement, source path/function/line, minimal reproduction, expected/actual behavior, accounting/control consequence, smallest sufficient correction, dependencies/order, exact acceptance assertions, regression tests, and any decision requiring client authority. Distinguish confirmed defects, unverified concerns, and deferred enhancements. If none are confirmed, return an empty confirmed-defect list rather than inventing work.
4. **`fable_reverification_probes.py`** — Independent runnable adversarial probes against a project-root argument, with explicit fixture/authority setup, temporary synthetic databases, exact assertions, and nonzero exit for a verified gate failure. Document the exact command. Do not use direct database edits to create successful accounting workflow outcomes.
5. **`fable_reverification_output.txt`** — Raw execution evidence with environment, commands, exit codes and stdout/stderr; preserve enough detail to reproduce every failure. If execution is unavailable, say so and provide the probes for local execution.

Return concrete corrective work, not another project-concept redesign. Do not approve the application merely because its own tests pass, and do not require deferred full-cycle capabilities to exist before accepting a properly bounded synthetic control. Where evidence or accounting authority is missing, state the precise unresolved question.
