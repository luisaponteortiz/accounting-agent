# Connection and release readiness

**Status: local synthetic only. No request to connect is pending.** A successful demo grants no additional authority.

- [x] General accounting module contracts and executable common runner
- [x] Synthetic profiles, evidence, work state, exceptions and version-bound review
- [x] Automated unit/integration/HTTP tests and local backup/restore exercise
- [x] Fable C-01–C-06 and assigned Batch 2 controls incorporated with synthetic regression evidence
- [ ] Independent Fable reverification of this source checkpoint and human G0 acceptance
- [ ] Luis/client validation of actual accounting system/migration, legal entity, accounts/currencies/periods, chart, procedures, source completeness and accounting policies
- [ ] Actual human preparer/reviewer/exception/close authority and client engagement/support responsibilities agreed
- [ ] Approved sample evidence with known reviewed results and independent validation cases
- [ ] Theresa's observed independent operation, teach-back, review/correction time, interruptions and escalation verified
- [ ] Hosting/platform capability/authority/costs agreed with Jeff and relevant owners
- [ ] Supported Python/service runtime, authenticated identity, scoped secret store, production persistence/migrations, logs, backups and restore tested
- [ ] Per-client connector capability inventory and provider documentation verified for the specific required operation
- [ ] Exact provider, purpose, account owner, data scope, read permissions, environment, cost ceiling and validation step authorized
- [ ] Real schedule/event delivery and evidence-freshness/period policies validated; no fixture authority promoted
- [ ] Live write capability separately designed, tested and authorized, including idempotency, unknown-outcome reconciliation and verification

Deferred adapters are **not implemented-unconnected connectors**. QBO, Desktop, bank/card feeds, Expensify, document providers and model APIs are all unconnected and no provider is selected. Do not copy company-wide credentials to a client deployment. A per-client future secret reference must resolve only within that client's authorized environment; raw keys never belong in profile JSON or exports.

The local HTTP server and synthetic role selector cannot be hosted. A hosted release requires a separate authenticated implementation and actual database/worker integration tests. No Render provisioning, infrastructure costs, subscription charges or accounting effects were incurred by this build.

## G0 synthetic evidence

The service-only walkthrough in scripts/synthetic_month.py processes the original teaching month: 11 independent preparation approvals, two explicitly dispositioned but still blocked pending/foreign items, two immutable preparation packages and a locked November. October's quarantined TX-008 is explicitly named in the acknowledgement. No fabricated receipt, FX rate or recognition policy clears a blocker. Another client's December workflow leaves all first-client artifact/review/package records unchanged. Account-impact totals and audit integrity are asserted.

Final automated results: 111 passing tests; reviewer cases 29 PASS / 10 FIXED / 21 DEFERRED-OK; corrective N01–N07 OK; no unexpected failures. Automated G0 criteria are documented in docs/BATCH_2_REPORT.md and docs/batch2/: original methods retained, all ten fail-until-fix reviewer cases fixed, no unexpected statuses, deferred capabilities refused, full month/isolation tests, immutable migration and corrective gates. Human G0 acceptance and Fable's independent re-verification remain pending. This evidence permits no connection, real sample use, model call, posting, payment, external close or production release. G1–G4 remain closed.
