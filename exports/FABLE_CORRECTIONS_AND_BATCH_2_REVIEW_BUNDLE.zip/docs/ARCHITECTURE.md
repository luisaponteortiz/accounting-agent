# General Accounting Agent OS — current architecture

This local synthetic platform retains Python standard library, SQLite and static HTML/JS. It provides common execution, evidence, knowledge, authority and review boundaries for six accounting areas. Card preparation, mechanical journal validation and close readiness execute; AP, AR, full reconciliation and reporting remain deferred.

## Shared execution and client knowledge

Every backend operation carries organization/client/environment scope. Profiles, approved policy versions, source identities/versions, periods, grants, runs, occurrences, decisions, dispositions and packages remain scoped. Profiles are proposed by registration; a separately granted human approves them. Rules record proposer, approver, effective dates, evidence and supersession. Handlers receive only approved rules effective on the item's date. Proposed changes confer no authority. Alias proposals expose their normalized form in audit evidence.

Client-specific chart, entity/book, currency, vendors, receipt matching, procedures and close checklist remain separate from shared invariants. Capabilities declare required facts; missing facts block client-sample preparation. Explicit explanatory waivers are allowed only for synthetic_demo profiles and are exported. No actual Bird Bowl policy or fact is supplied by these waivers.

Capabilities declare rule kinds and date-governing source kinds as well as source/profile reads. Unrelated close-policy changes preserve card/journal approvals and mandates; item-effective review policy governs required model holds. Pure handlers receive declared source/profile inputs, committed dependency outputs and relevant dispositions. They cannot query storage, approve work, call a model or invoke external effects. The runner persists exact manifests, checkpoints, bounded leases and retry attempts. Dependency package controls propagate by default; a blocked inventory cannot yield an unblocked downstream package. Close readiness waits for earlier queued/running preparation in its period, then captures completed upstream outcomes when its execution begins; this refresh changes only that outcome dependency, never silently adopts revised sources/policy.

## Durable periods and source lifecycle

Periods are durable records with immutable status history. Lock/reopen requires a granted, independent human. Locked periods refuse dispatch and every review decision. Unsettled governing work requires an explicit recorded acknowledgement before lock. A lock preserves completed run references; it does not change historical accounting evidence.

Sources accept explicit timestamp or sequence as_of, tombstones and supersession. Older/conflicting versions remain history without replacing the accepted head. Legacy fictional arrivals explicitly use arrival order; batch names are not provider sequences. Superseded pending authorizations leave the current population with links retained. Approved-source revision/removal raises an accounting event. Replays use accepted head bytes and can re-evaluate unassigned bindings.

Dated sources route to their accounting period. Receipts follow the referenced transaction's period but retain their receipt date for policy matching. Unassigned evidence remains quarantined until its period opens. A move from a locked origin is quarantined with both period IDs; it enters no destination preparation. Reopening the origin re-evaluates the move and makes old preparation stale before the destination can govern. Historical versions and immutable artifact bytes are never rewritten.

## Accounting substance

Structured fictional statements declare balances, signed totals by activity, line count/identities and provenance. Workpapers disclose excluded/pending/foreign population; checks compare balance arithmetic, activity totals, identity and prior closing balance. The demonstrated statement cycle equals the configured period; other cycle-to-period policies require client validation. Legacy count/total controls alone cannot confer eligibility. The test-only reviewer adapter constructs explicit fictional specifications, never runtime statement evidence.

Shared proposed_entry records bind entity, book, period, currency, lines/dimensions, entry type, origin references and not_posted status. One common validator checks mechanical balance, account, line, scope, currency and period constraints. Current client dimension activation remains deferred. Card entries use an explicit fictional liability mapping. Overlapping origin claims hold both preparations. Journals additionally require journal-bound support, duplicate checks and a nonzero effect by account/dimension. None of this establishes correct recognition, tax treatment or actual ledger balances.

Exceptions have current status plus immutable history. Granted humans select evidence-bound item dispositions from a closed vocabulary. Re-preparation cites these decisions and still requires independent review. Split allocations must sum exactly. A proposed reusable rule does not resolve an item or activate policy. Revocation re-blocks preparation. Explicit refer_external dispositions retain their original pending/currency/missing-document blockers; they never make an item eligible.

Receipt matching uses approved parameters with explicit null values: date window, amount tolerance, multiple receipts, vendor method and statement substitution. Unset parameters retain exact matching and name the unset policy when a mismatch arises. No default tolerance is shipped.

## Content identity, independence and finalization

One completed governing artifact exists per workflow/period/item. Byte-identical work reuses its artifact and decisions across execution actors. Contributors are append-only provenance outside the content hash. Review uses the union of legacy envelope provenance and every linked-run contributor. Item lineage includes all historical suppliers of its evidence/duplicate inputs, applied rule proposers/approvers, disposition actors, enqueue actor, worker and mandate issuer. Supplying another item's receipt does not bar review of this item.

Decisions bind the exact artifact/hash/fingerprint and require a granted non-contributing human. Conflicts create disputed; explicit independent resolution is required. Mistaken revocation can be resolved by a new independent human. An overruled reviewer cannot repeatedly reopen a resolved judgment on unchanged preparation. All prior decisions remain immutable.

A granted independent human may finalize an immutable preparation package containing governing IDs/hashes/content, decisions, contributor sets, dispositions, manifest/rule versions, explicitly carried exceptions and the audit head. Disputed/stale items and package controls refuse finalization. Unreviewed or item-level carried work requires an explicit acknowledgement. This is preparation handover, not ledger posting or external close. Later input/decision changes raise POST_FINALIZATION_CHANGE; frozen package payload/hash remain byte-stable.

Close readiness evaluates typed workflow outcomes and period/account-bound evidence. A typed reconciliation/tieout requirement needs a verified workflow outcome; a document label cannot complete a deferred capability. It discloses stale, disputed, blocked, unreviewed and quarantined work. External verification and final close sign-off holds always remain; placeholder documents cannot prove an external reconciliation.

## Recurring work and limits

Mandates are proposed until a separately granted human approves them. They bind policy versions, explicit fixed/calendar/previous-month period selection, timestamp freshness predicates, expiry, occurrence caps and workflow scope. Missing fresh evidence leaves awaiting_evidence; intake can wake that occurrence on the persisted simulated clock. Changed policy suspends authority pending reconfirmation. A held run can release its occurrence for redispatch; one completed run per occurrence is enforced. No real scheduler is activated.

The local identity selector/grant fixture is a test harness, not authentication. Live connectors, models, posting, payments, production deployment and paid hosting are absent. Full export still uses two transactions with an input-change guard; atomic decision-consistent export and externally anchored audit are T-25, outside this batch. Worker failure classification/backoff/heartbeat, broader currency support and bounded production reads remain Batch 3. Finalized package bytes are immutable despite these live-export limitations. Schema migrations preserve historical records; tests cover concurrent migration, foreign keys, restart and immutable legacy bytes.
