# Accounting Agent OS — implementation progress

Status: **C-01–C-06 corrected; Batch 2 T-09–T-19 complete; final regression gate passed.** Local, fictional accounting data only. Python/SQLite foundation retained. No Batch 3 functionality or live systems activated.

## Corrective gate completed first

All N01–N07 failures were reproduced before changes. Corrections followed Fable's order: C-05, C-06, C-02, C-04, C-03, C-01. The exact unmodified supplied script passed N01–N07 and its other required checks at that checkpoint. Full corrective suite: 81 tests, 76 passes and five then-deferred expected failures. All original 41 methods retained.

The frozen source and evidence are in exports/FABLE_CORRECTIVE_C01_C06_REVIEW_BUNDLE.zip. docs/CORRECTIVE_REPORT.md and docs/corrections/ retain before/after evidence. T-12, T-14 and T-18 began only after that gate passed. All four supplied verification inputs remain unchanged.

## Batch 2 implemented in prescribed order

| Tickets | What runs | Main verification | Unconnected or deliberately limited |
| --- | --- | --- | --- |
| T-09, T-11 | Proposed/approved effective profiles and rules, explicit human grants, required facts and exported synthetic waivers | Proposed policy inert; self/service approval refused; later policy preserves prior-period review; client_sample missing basis held | Actual client facts, authority and policy validation |
| T-12 | Source sequence/timestamp ordering, removals, supersession, evidence binding and quarantine recovery | Older delivery/replay cannot regress accepted head; unchanged-content tombstone; receipt boundary; lock/move/reopen uniqueness | Live provider source semantics |
| T-10 | Independently approved mandates bound to policy, period rules, freshness and expiry | Fixed prior-period target; no fresh evidence means awaiting_evidence; intake wake-up; changed policy suspends | Real schedules, external event delivery |
| T-13 | Structured statement/activity/balance/population checks and excluded-population workpapers | Same-total identity swap, activity mismatch, opening break, signed payment | Actual statement verification and noncalendar cycle policy; full reconciliation |
| T-14 | Persistent exceptions/history, closed-vocabulary evidence-bound dispositions, revocation and dependency propagation | Distinct purchases, exact split, service denial, proposed rule inert, item-specific historical contributors, empty inventory hold | Actual exception authority; foreign currency and pending sources remain held |
| T-15, T-16 | Shared proposed entry/validator, origin collision holds, journal-bound support, duplicate and zero-effect controls | Independent FV-J01–J10, separate adversarial journal tests, entry impact hand calculation | Ledger entries, recognition policy, dimensions and posting |
| T-17 | Approved nullable receipt matching parameters | Unset policy codes; proposed rule inert; one-day/two-day and five-/six-cent boundary tests | Authenticity/OCR and actual document policy |
| T-18, T-19 | Immutable preparation packages, post-finalization events, acknowledged lock preconditions, review recovery/bounded dispute, outcome-aware close readiness | Frozen package round-trip; disputed/preparer denial; wrong-period/label-only evidence; full teaching month and second-client isolation | Actual ledger close, reconciliations, AP/AR ties and external final sign-off |

The teaching-month service-only walkthrough approves 11 items, explicitly dispositions two held items without removing their pending/currency blockers, finalizes two preparation packages and locks November. October's TX-008 remains quarantined and is named in the handover acknowledgement. A second client's December journal runs without changing November records or packages. Proposed-entry net impact balances; the independently hand-calculated totals are asserted in tests. No direct database edits are used.

## Gates and review evidence

Final make test: **111 tests passed**, no expected failures or unexpected regressions. All 41 original platform/HTTP methods are retained and pass. Final make batch2-gate: **29 PASS / 10 FIXED / 21 DEFERRED-OK**, no failing reviewer cases; current N01–N07 and all required implemented probes OK. make check passes. Runtime: Python 3.9.6 / SQLite 3.51.0.

The maintained 60-case suite requires all ten original fail-until-fix cases to be FIXED. FV-CL04 is now executable with period-bound evidence. Remaining deferred capability specifications are still refused; they are not required to pass as accounting operations.

The original verifier's pre-Batch-2 setup assumes immediately active profiles/mandates. Current tests use review/batch2_verification_probes.py with explicit grants, independent approvals, structured fictional statements and lock acknowledgements. Control assertions remain enforced and additional implemented probes are now gates. scripts/verify_corrective_checkpoint.py re-runs the unmodified supplied script against the frozen corrective source. This contract adaptation does not auto-approve production policy or modify Fable's inputs.

Final execution results, per-case classifications, source patches and exact commands are recorded in docs/BATCH_2_REPORT.md and docs/batch2/. Historical Batch 1 reports and correction logs describe their own checkpoints, not current functionality. All 41 original platform/HTTP method names remain present; deliberate expectation changes are documented in DECISIONS.md.

## Remaining boundary

No Batch 3 started. Full statement reconciliation, settlement pairing, trial-balance intake, AP/AR, reporting, broader currencies, production reliability/identity, atomic live export and external audit anchoring remain deferred. Actual Bird Bowl facts, policies, systems and authority remain unconfigured. G0 software evidence does not grant G1 sample use or any connection, posting, payment, paid service or deployment authority. Independent Fable verification and human acceptance are pending.

## Reverification prompt and bundle

FABLE_REVERIFICATION_PROMPT.md contains the exact instructions to send with the updated review bundle. It requests separate historical/current corrective verdicts, every assigned Batch 2 acceptance criterion, all 60 case results, independent adversarial probes, and prioritized corrections for Codex. The packaging and change-report scripts include the prompt explicitly. Application controls and acceptance criteria are unchanged. Packaging checks and the repository-required regression rerun are recorded in docs/batch2/reverification-prompt-check.txt and reverification-prompt-tests.txt.
