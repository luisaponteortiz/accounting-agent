"""Immutable preparation handover; does not finalize a ledger or external close."""
import json
from .core import ControlError, canonical, digest, text_field, utcnow

PACKAGE_CODES={'NO_SOURCE_EVIDENCE','MODEL_REVIEW_UNAVAILABLE','SOURCE_ALREADY_HAS_ENTRY'}

def package_blocker(code):
    return code in PACKAGE_CODES or code.startswith(('STATEMENT_','CLIENT_FACT_MISSING:'))

class PackageControls:
    def period_outcomes(self,db,actor,period_id):
        items=[]
        rows=db.execute("SELECT DISTINCT a.*,r.workflow FROM artifacts a JOIN artifact_runs l ON l.artifact_id=a.id JOIN runs r ON r.id=l.run_id WHERE a.scope=? AND r.period_id=? AND r.workflow IN ('card_preparation','journal_preparation') AND a.kind IN ('card_proposal','journal_proposal') ORDER BY a.id",(actor.scope,period_id)).fetchall()
        for a in rows:
            if a['item_key'] in ('no-transactions','no-journals') or self.governing_id(db,actor.scope,a['workflow'],period_id,a['item_key'])!=a['id']:continue
            links=db.execute('SELECT r.* FROM runs r JOIN artifact_runs l ON l.run_id=r.id WHERE l.artifact_id=? AND l.scope=?',(a['id'],actor.scope)).fetchall()
            current=any(r['status'] in ('awaiting_review','prepared_with_exceptions') and self._current(db,actor,r) for r in links)
            decisions=[dict(d) for d in db.execute('SELECT * FROM decisions WHERE scope=? AND artifact_id=? ORDER BY id',(actor.scope,a['id']))]
            items.append({'id':a['id'],'hash':a['hash'],'workflow':a['workflow'],'item_key':a['item_key'],'status':self.review_state(decisions) if current else 'stale','blockers':json.loads(a['blockers']),'decisions':decisions,'contributors':self.contributors(db,actor.scope,a),'payload':json.loads(a['payload'])})
        quarantined=[dict(r) for r in db.execute('SELECT b.*,s.source_key FROM source_periods b JOIN snapshots s ON s.id=b.snapshot_id WHERE b.scope=? AND (b.period_id=? OR b.period_id IS NULL) AND b.admitted=0 AND b.id=(SELECT MAX(x.id) FROM source_periods x WHERE x.snapshot_id=b.snapshot_id) AND EXISTS(SELECT 1 FROM source_heads h WHERE h.snapshot_id=b.snapshot_id AND h.removed=0)',(actor.scope,period_id))]
        return {'items':items,'quarantined_sources':quarantined,'packages':[dict(r) for r in db.execute('SELECT id,workflow,hash FROM packages WHERE scope=? AND period_id=?',(actor.scope,period_id))]}

    def finalize_package(self,actor,period_id,workflow,reason,acknowledgement=None):
        self.authorize(actor,('reviewer',));text_field(reason,'finalization reason',2000)
        with self.store.transaction() as db:
            self.require_grant(db,actor,'finalize')
            if self.period(db,actor,period_id)['status']=='locked':raise ControlError('PERIOD_LOCKED',409)
            ctx=self.context(db,actor,period_id,workflow)
            outcomes=self.period_outcomes(db,actor,period_id);items=[i for i in outcomes['items'] if i['workflow']==workflow]
            if not items:raise ControlError('No preparation items to finalize',409)
            if any(i['status'] in ('disputed','stale') for i in items):raise ControlError('Stale/disputed items cannot be finalized',409)
            if any(package_blocker(c) for i in items for c in i['blockers']):raise ControlError('Package control remains open',409)
            carried=[{'item_key':i['item_key'],'status':i['status'],'blockers':i['blockers']} for i in items if i['status']!='approve' or i['blockers']]
            if (carried or outcomes['quarantined_sources']) and not acknowledgement:raise ControlError('Unreviewed/carried exceptions require acknowledgement',409)
            if acknowledgement:text_field(acknowledgement,'acknowledgement',2000)
            for i in items:
                a=db.execute('SELECT * FROM artifacts WHERE scope=? AND id=?',(actor.scope,i['id'])).fetchone()
                contributors=self.contributors(db,actor.scope,a)
                if contributors is None or actor.id in contributors:raise ControlError('Independent finalizer required',403)
            head=db.execute('SELECT hash FROM audit WHERE scope=? ORDER BY id DESC LIMIT 1',(actor.scope,)).fetchone()
            value={'scope':actor.scope,'period_id':period_id,'workflow':workflow,'items':items,'manifest':ctx['manifest'],'dispositions':ctx['dispositions'],'rule_versions':ctx['manifest']['rules'],'open_exceptions':carried,'quarantined_sources':outcomes['quarantined_sources'],'acknowledgement':acknowledgement,'reason':reason,'audit_head':head['hash'] if head else None,'authority':'preparation_only_not_external_close','finalizer':actor.id}
            hashed=digest(value)
            pid=db.execute('INSERT INTO packages(scope,workflow,period_id,payload,hash,actor,created) VALUES(?,?,?,?,?,?,?)',(actor.scope,workflow,period_id,canonical(value),hashed,actor.id,utcnow())).lastrowid
            self.store.audit(db,actor.scope,actor.id,'preparation_package_finalized',{'package_id':pid,'hash':hashed})
            return pid

    def package_changes(self,db,actor):
        for p in db.execute('SELECT * FROM packages WHERE scope=?',(actor.scope,)).fetchall():
            value=json.loads(p['payload']);ctx=self.context(db,actor,p['period_id'],p['workflow'])
            current=[i for i in self.period_outcomes(db,actor,p['period_id'])['items'] if i['workflow']==p['workflow']]
            changed=digest(value['manifest'])!=digest(ctx['manifest']) or digest(value['items'])!=digest(current)
            if changed and not db.execute("SELECT 1 FROM accounting_events WHERE scope=? AND code='POST_FINALIZATION_CHANGE' AND payload=?",(actor.scope,canonical({'package_id':p['id'],'current_fingerprint':ctx['fingerprint']}))).fetchone():
                self.accounting_event(db,actor,p['period_id'],'package:'+str(p['id']),'POST_FINALIZATION_CHANGE',{'package_id':p['id'],'current_fingerprint':ctx['fingerprint']})
