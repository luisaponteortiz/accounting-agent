"""Evidence-bound item decisions. Dispositions never confer review or posting authority."""
import json
from decimal import Decimal
from .core import ControlError, canonical, money, text_field, utcnow

VOCABULARY={
 'POSSIBLE_DUPLICATE':{'distinct_purchases','duplicate_of','source_replay'},
 'UNKNOWN_VENDOR':{'confirm_vendor'},'UNKNOWN_CATEGORY':{'code_category'},
 'CREDIT_REQUIRES_REVIEW':{'refund_of','standalone_credit'},
 'NON_EXPENSE_REQUIRES_REVIEW':{'settlement_of_card_liability','transfer','standalone_credit'},
 'SPLIT_REQUIRES_REVIEW':{'allocate'},
 'SOURCE_TRANSITION_REQUIRES_REVIEW':{'settlement_verified'},
 'CURRENCY_MISMATCH':{'refer_external'},'PENDING_TRANSACTION':{'refer_external'},'MISSING_RECEIPT':{'refer_external'},
}

class ExceptionControls:
    def active_dispositions(self,db,actor,workflow,period_id,sources):
        heads={s['source_key']:s for s in sources};result=[]
        for r in db.execute("SELECT * FROM dispositions d WHERE scope=? AND workflow=? AND period_id=? AND action='apply' AND NOT EXISTS(SELECT 1 FROM dispositions x WHERE x.scope=d.scope AND x.prior_id=d.id AND x.action='revoke') ORDER BY id",(actor.scope,workflow,period_id)):
            row=dict(r);source=heads.get(row['item_key']);evidence=json.loads(row['evidence'])
            if source and source['hash']==row['source_hash'] and all(any(s['id']==e['snapshot_id'] and s['hash']==e['hash'] for s in sources) for e in evidence):
                row['payload']=json.loads(row['payload']);row['evidence']=evidence;result.append(row)
        chosen={}
        for r in result:chosen[(r['item_key'],r['code'])]=r
        return list(chosen.values())

    def disposition(self,actor,workflow,period_id,item_key,code,choice,payload,evidence,reason,scope_kind='single_item'):
        self.authorize(actor,('reviewer',));text_field(reason,'disposition reason',2000)
        if scope_kind not in ('single_item','propose_rule'):raise ControlError('Unsupported disposition scope')
        if choice not in VOCABULARY.get(code,set()):raise ControlError('Unsupported disposition; this control cannot be overridden')
        with self.store.transaction() as db:
            self.require_grant(db,actor,'disposition')
            if self.period(db,actor,period_id)['status']=='locked':raise ControlError('PERIOD_LOCKED',409)
            ctx=self.context(db,actor,period_id,workflow);source=next((s for s in ctx['sources'] if s['source_key']==item_key),None)
            current=self.governing_id(db,actor.scope,workflow,period_id,item_key)
            a=db.execute('SELECT * FROM artifacts WHERE scope=? AND id=?',(actor.scope,current)).fetchone()
            if not source or not a or code not in json.loads(a['blockers']):raise ControlError('No governing exception for this source',409)
            if not evidence or any(not any(s['id']==e.get('snapshot_id') and s['hash']==e.get('hash') for s in ctx['sources']) for e in evidence):raise ControlError('Current scoped evidence references required')
            if choice=='settlement_of_card_liability' and source['value'].get('activity')!='payment':raise ControlError('Settlement requires a payment source')
            if choice=='transfer' and source['value'].get('activity')!='transfer':raise ControlError('Transfer requires a transfer source')
            if scope_kind=='propose_rule':
                rule=payload.get('rule',{})
                self.validate_rule(rule.get('kind'),rule.get('value'))
                from .core import day
                day(rule['effective_from'])
                return self._propose_rule(db,actor,rule['kind'],rule['key'],rule['value'],rule['effective_from'],None,None,None,evidence,None)
            accounts={a['id'] for a in ctx['profile']['accounts'] if a['active']}
            if choice in ('code_category','standalone_credit','refund_of','confirm_vendor') and payload.get('account_id') not in accounts:raise ControlError('Active account required')
            if choice in ('settlement_of_card_liability','transfer') and payload.get('cash_account') not in accounts:raise ControlError('Active cash/clearing account required')
            if choice in ('duplicate_of','source_replay') and payload.get('duplicate_of') not in {s['source_key'] for s in ctx['sources'] if s['kind']=='transaction' and s['source_key']!=item_key}:raise ControlError('Scoped duplicate target required')
            if choice=='refund_of':
                target=next((s for s in ctx['sources'] if s['kind']=='transaction' and s['source_key']==payload.get('refund_of')),None)
                if not target or target['value']['currency']!=source['value']['currency'] or target['value']['account_id']!=source['value']['account_id'] or money(target['value']['amount'])<=0:raise ControlError('Scoped original purchase reference required')
            if choice=='allocate':
                lines=payload.get('allocations',[])
                if not lines or len(lines)>99 or any(l.get('account_id') not in accounts or money(l['amount'])<=0 for l in lines) or sum((money(l['amount']) for l in lines),Decimal('0.00'))!=money(source['value']['amount']):raise ControlError('Allocation must sum exactly to charge')
            rid=db.execute("INSERT INTO dispositions(scope,workflow,period_id,item_key,code,choice,payload,evidence,source_hash,actor,reason,action,created) VALUES(?,?,?,?,?,?,?,?,?,?,?,'apply',?)",(actor.scope,workflow,period_id,item_key,code,choice,canonical(payload),canonical(evidence),source['hash'],actor.id,reason,utcnow())).lastrowid
            self.package_changes(db,actor)
            self.store.audit(db,actor.scope,actor.id,'exception_dispositioned',{'id':rid,'item_key':item_key,'code':code,'scope':'single_item','reason':reason})
            return rid

    def revoke_disposition(self,actor,disposition_id,reason):
        self.authorize(actor,('reviewer',));text_field(reason,'reason')
        with self.store.transaction() as db:
            self.require_grant(db,actor,'disposition');r=db.execute('SELECT * FROM dispositions WHERE scope=? AND id=? AND action=\'apply\'',(actor.scope,disposition_id)).fetchone()
            if not r:raise ControlError('Disposition not found',404)
            if self.period(db,actor,r['period_id'])['status']=='locked':raise ControlError('PERIOD_LOCKED',409)
            if db.execute("SELECT 1 FROM dispositions WHERE scope=? AND prior_id=?",(actor.scope,disposition_id)).fetchone():raise ControlError('Already revoked',409)
            db.execute("INSERT INTO dispositions(scope,workflow,period_id,item_key,code,choice,payload,evidence,source_hash,actor,reason,action,prior_id,created) VALUES(?,?,?,?,?,?,?,?,?,?,?,'revoke',?,?)",(actor.scope,r['workflow'],r['period_id'],r['item_key'],r['code'],r['choice'],r['payload'],r['evidence'],r['source_hash'],actor.id,reason,disposition_id,utcnow()))
            self.package_changes(db,actor)
            self.store.audit(db,actor.scope,actor.id,'disposition_revoked',{'id':disposition_id,'reason':reason})

    def record_exceptions(self,db,scope,workflow,period_id,item,artifact,blockers,dispositions):
        previous={r['code']:r['status'] for r in db.execute('SELECT * FROM exceptions WHERE scope=? AND workflow=? AND period_id=? AND item_key=?',(scope,workflow,period_id,item))}
        resolved={d['code'] for d in dispositions if d['item_key']==item}
        for code in set(previous)|set(blockers)|resolved:
            status='dispositioned' if code in resolved else 'open' if code in blockers else 'superseded'
            db.execute('INSERT INTO exceptions VALUES(?,?,?,?,?,?,?) ON CONFLICT(scope,workflow,period_id,item_key,code) DO UPDATE SET status=excluded.status,artifact_id=excluded.artifact_id',(scope,workflow,period_id,item,code,status,artifact))
            if previous.get(code)!=status:db.execute('INSERT INTO exception_history(scope,workflow,period_id,item_key,code,status,artifact_id,created) VALUES(?,?,?,?,?,?,?,?)',(scope,workflow,period_id,item,code,status,artifact,utcnow()))
