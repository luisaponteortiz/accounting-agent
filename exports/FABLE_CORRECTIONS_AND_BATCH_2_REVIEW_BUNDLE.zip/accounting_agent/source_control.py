"""Ordered source lifecycle and scoped provenance; no connector operations."""
import json
from .core import ControlError, canonical, instant, utcnow


class SourceControl:
    def source_revision(self,db,actor,source,packet):
        kind,key,value=source['kind'],source['key'],source['data']
        old=db.execute('SELECT s.*,h.removed FROM source_heads h JOIN snapshots s ON s.id=h.snapshot_id WHERE h.scope=? AND h.kind=? AND h.source_key=?',(actor.scope,kind,key)).fetchone()
        as_of=source.get('as_of')
        if type(as_of) is int and as_of>=0:order_type,order_value='sequence',str(as_of)
        elif isinstance(as_of,str):order_type,order_value='timestamp',instant(as_of).isoformat()
        elif as_of is None:order_type,order_value='legacy_arrival',utcnow()
        else:raise ControlError('Invalid source as_of')
        system=source.get('source_system',value.get('source_system','fixture'))
        if system!='fixture':raise ControlError('Only fictional source systems are enabled',403)
        removed=source.get('tombstone',False)
        if type(removed) is not bool:raise ControlError('Invalid tombstone')
        reason=source.get('removal_reason')
        if removed and reason not in ('feed_removed','voided','superseded'):raise ControlError('Removal reason required')
        oldmeta=db.execute('SELECT * FROM source_metadata WHERE snapshot_id=?',(old['id'],)).fetchone() if old else None
        force=bool(old and int(removed)!=old['removed']) or bool(oldmeta and (oldmeta['order_type']!=order_type or oldmeta['as_of']!=order_value) and as_of is not None)
        sid,is_new=self.store.snapshot(db,actor.scope,kind,key,value,actor.id,force_version=force)
        if not is_new:
            b=db.execute('SELECT * FROM source_periods WHERE snapshot_id=? ORDER BY id DESC LIMIT 1',(sid,)).fetchone()
            if b and not b['admitted'] and b['reason']=='UNASSIGNED_ACCOUNTING_PERIOD':self.bind_source(db,actor,sid,value,packet.get('period_id'))
            return sid,False
        accepted=True
        if oldmeta and order_type==oldmeta['order_type'] and order_type!='legacy_arrival':
            if (int(order_value)<int(oldmeta['as_of']) if order_type=='sequence' else order_value<oldmeta['as_of']):accepted=False
            if order_value==oldmeta['as_of'] and old['hash']!=__import__('accounting_agent.core',fromlist=['digest']).digest(value):accepted=False
        elif oldmeta and order_type!=oldmeta['order_type'] and oldmeta['order_type']!='legacy_arrival':accepted=False
        db.execute('INSERT INTO source_metadata VALUES(?,?,?,?,?,?,?,?)',(sid,actor.scope,system,order_type,order_value,int(removed),reason,packet.get('period_id') or value.get('period_id')))
        if not accepted:
            self.store.audit(db,actor.scope,actor.id,'older_or_conflicting_source_retained',{'snapshot_id':sid,'governing_snapshot_id':old['id'] if old else None})
            return sid,False
        db.execute('INSERT INTO source_heads(scope,kind,source_key,snapshot_id,removed) VALUES(?,?,?,?,?) ON CONFLICT(scope,kind,source_key) DO UPDATE SET snapshot_id=excluded.snapshot_id,removed=excluded.removed',(actor.scope,kind,key,sid,int(removed)))
        self.bind_source(db,actor,sid,value,packet.get('period_id') or value.get('period_id'))
        if old and old['hash']!=__import__('accounting_agent.core',fromlist=['digest']).digest(value) or old and removed:
            for a in db.execute('SELECT a.*,r.period_id FROM artifacts a JOIN runs r ON r.id=a.run_id WHERE a.scope=?',(actor.scope,)):
                if a['item_key']==key and db.execute("SELECT 1 FROM decisions WHERE artifact_id=? AND scope=? AND decision IN ('approve','resolve_approve')",(a['id'],actor.scope)).fetchone():
                    self.accounting_event(db,actor,a['period_id'],key,'APPROVED_SOURCE_REMOVED' if removed else 'APPROVED_SOURCE_REVISED',{'artifact_id':a['id'],'snapshot_id':sid})
        supersedes=source.get('supersedes') or value.get('supersedes_source_id')
        if supersedes:
            old_key=supersedes if ':' in supersedes else value.get('account_id','')+':'+supersedes
            prior=db.execute('SELECT * FROM source_heads WHERE scope=? AND kind=? AND source_key=?',(actor.scope,kind,old_key)).fetchone()
            if prior and prior['snapshot_id']!=sid:
                db.execute('UPDATE source_heads SET removed=1 WHERE scope=? AND kind=? AND source_key=?',(actor.scope,kind,old_key))
                db.execute('INSERT INTO source_links(scope,old_snapshot_id,new_snapshot_id,reason,created) VALUES(?,?,?,\'superseded\',?)',(actor.scope,prior['snapshot_id'],sid,utcnow()))
        self.store.audit(db,actor.scope,actor.id,'source_revision_accepted',{'snapshot_id':sid,'source_key':key,'as_of':order_value,'ordering':order_type,'removed':removed,'reason':reason})
        return sid,True

    def accounting_event(self,db,actor,period_id,item_key,code,value):
        db.execute('INSERT INTO accounting_events(scope,period_id,item_key,code,payload,actor,created) VALUES(?,?,?,?,?,?,?)',(actor.scope,period_id,item_key,code,canonical(value),actor.id,utcnow()))
