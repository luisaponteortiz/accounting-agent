# Accounting Agent OS

A reusable accounting execution foundation for isolated clients, with shared execution, evidence, policy and approval controls. Bird Bowl is the first client implementation. The six accounting areas remain the product architecture; this release demonstrates card preparation, journal validation and close readiness on fictional data.

## Run locally

Requires Python 3.9+ and SQLite; tested on Python 3.9.6. No dependencies, API keys, paid services or hosting required.

```sh
make demo
```

Open http://127.0.0.1:8765. A background worker continues queued work. Ctrl+C stops it; SQLite retains progress. This command seeds only the fictional demo, independently approves its test profile/grants, and starts three workflows. It does not activate real policy. Back up existing synthetic databases before migration. Historical records remain immutable.

For an isolated scratch database:

```sh
python3 -m accounting_agent demo --db /private/tmp/accounting-os-synthetic.sqlite3
```

Other commands:

```sh
make test
make check
make batch2-gate
python3 scripts/synthetic_month.py
python3 scripts/verify_corrective_checkpoint.py
python3 -m accounting_agent inspect
make export-demo
make backup
```

Tests use temporary databases and loopback servers; the sandbox may require loopback permission. Full tests include both reviewer gates and the teaching-month walkthrough. check performs offline syntax/JSON/profile/registry checks; it is not an external linter or JavaScript build. Backup refuses to overwrite an existing destination. CLI --db/--output select alternative synthetic paths.

## Implemented and unconnected

| Component | Running behavior | Still unconnected or deferred |
| --- | --- | --- |
| Common engine | Durable DAG jobs, leases/checkpoints/recovery, scoped periods, source lifecycle, manifests, evidence and audit | Production queue, worker backoff/heartbeat and hosted persistence |
| Client knowledge | Independently approved effective profiles/rules, explicit grants, fact requirements and synthetic waivers | Actual Bird Bowl facts/policies/authority, real identity and credentials |
| Card preparation | Vendor/category proposals, duplicates, document policies, statement checks, dispositions and derived entries | Real feeds/OCR, full reconciliation, FX and posting |
| GL preparation | Shared entry validator, support binding, duplicate/no-effect/origin collision controls | Ledger balances, accrual creation, recognition policy and posting |
| Close readiness | Typed outcome/evidence checks, quarantined/unreviewed work and immutable preparation handover | External reconciliations, AP/AR ties and actual close sign-off |
| Recurrence | Independently approved bounded mandates with period/freshness predicates and simulated events | Live schedules and external event delivery |
| Other accounting areas | Six-area contracts and refused deferred tools | AP, AR, full banking/reconciliation, reporting and analysis execution |

All approvals concern preparation. No connector, model call, ledger write, payment, production deployment or paid hosting is enabled. The local role selector and fixture grants are artificial identities, not authentication or participation by real people.

## Demonstrate the controls

1. Inspect 11 November card items, two journals and the close checklist. October's transaction is quarantined pending its period. Structured statement checks also produce a workpaper. The original intentionally defective items remain blocked.
2. Switch to Demo independent reviewer, inspect a clean item, enter a reason and approve. Source/preparation/rule/disposition contributors cannot review their own work; all historical versions of the item's evidence count.
3. Supply the fictional missing receipt as preparer and re-prepare cards. Journal review stays current. Policy changes require separate proposed/approved records through the Python service.
4. Reviewers can record a supported item disposition, then re-prepare. A different independent human must review that item; the two-role UI cannot impersonate additional reviewers. scripts/synthetic_month.py demonstrates the full multi-person service sequence, including distinct purchases, a split, credit and settlement.
5. Finalize a preparation package with an explicit acknowledgement of any carried item exceptions. Stale/disputed work and package controls refuse. Locked periods refuse all decisions; unsettled work requires a recorded lock acknowledgement. Reopening is audited.
6. Propose a fictional mandate, switch to reviewer to approve it, then deliver simulated events as preparer. A repeated event reuses its occurrence; freshness and policy changes can hold future work. The UI's explicit empty freshness rule is a demo choice, not real client standing authority.
7. Export scoped evidence, rule/grant/decision histories, exceptions, immutable packages and audit. Full live export's transaction-consistency hardening remains T-25; finalized package bytes remain fixed.

See [architecture](docs/ARCHITECTURE.md), [capability contracts](docs/CAPABILITY_CONTRACTS.md), [current report](docs/BATCH_2_REPORT.md) and [Fable reverification instructions](docs/FABLE_CORRECTION_REVERIFY.md). The original ss_agent_system_handoff/ package is preserved as reference; executive/marketing/sales work remains outside scope.

The corrective checkpoint passed the supplied unmodified verifier before Batch 2. Current review harnesses explicitly model the newer approval/source contracts; all original verification inputs are preserved. make batch2-gate requires all executable fixes and refuses deferred capabilities. Historical expected-failure assertions have been removed as their controls became implemented.
