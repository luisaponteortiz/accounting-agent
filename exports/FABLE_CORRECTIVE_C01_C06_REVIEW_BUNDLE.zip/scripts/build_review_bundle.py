"""Package reviewable source/evidence, excluding runtime data and credentials."""
import hashlib
import json
import sys
import zipfile
from pathlib import Path

root=Path(__file__).resolve().parents[1]
label=sys.argv[1]
files=[root/n for n in ('AGENTS.md','README.md','PROGRESS.md','DECISIONS.md','FABLE_ACCOUNTING_HANDOFF.md','FABLE_REVIEW_PROMPT.md','Makefile')]
for folder in ('accounting_agent','tests','scripts','review','docs','exports/FABLE_BATCH_1_VERIFICATION'):
    files.extend(p for p in (root/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.sqlite3','.db'))
files=sorted(set(files))
manifest={'label':label,'scope':'Local fictional accounting preparation only; no database, credentials, live records, posting or deployment authority.', 'files':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
bundle=root/'exports'/(label+'_REVIEW_BUNDLE.zip')
with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED) as archive:
    for p in files:archive.write(p,p.relative_to(root))
    archive.writestr('REVIEW_MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(bundle) as archive:
    assert archive.testzip() is None
    for name,value in manifest['files'].items():assert hashlib.sha256(archive.read(name)).hexdigest()==value
print(bundle)
print('Verified',len(files),'source/evidence files')
