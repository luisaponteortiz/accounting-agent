# Accounting Agent OS project instructions

The user's project scope supersedes the broader Supporting Strategies reference handoff. Build a reusable general accounting execution platform covering GL, AP, AR, banking/reconciliation, month-end close and financial reporting/analysis. Bird Bowl is the first client implementation; card preparation is one demonstration, not the product boundary. Do not implement executive, marketing, sales or other non-accounting agents here.

Keep shared controls/workflow tools separate from client policies, chart, vendors/customers, systems, decisions, procedures and credentials. Enforce organization/client/environment scope in backend reads, jobs, evidence, approvals and exports. Unknown Bird Bowl facts stay unknown; all current accounts, mappings, financial data and review identities are fictional.

Current build is local/demo only. Do not connect real systems, invoke paid models, post entries, send messages, execute payments, deploy or incur hosting costs without specific authorization. Do not promote synthetic profiles or approvals into real operation. No model proposal may grant authority or activate policy.

Preserve the original `ss_agent_system_handoff/` package. Maintain `PROGRESS.md`, `DECISIONS.md`, `docs/CONNECTION_READINESS.md` and the Fable handoff. Record honest capability states; no full-cycle, production or human operating-readiness claim from fixtures. Run `make test` and relevant checks after code changes. Local HTTP tests need loopback-port access. Do not add unrelated toolchains just to claim a standard stack.

For substantial writing/strategy representing Luis, apply the user's global `/Users/luis/.codex/USER_PROFILE.md` instruction as a lens, subject to project audience/purpose.

Batch 1 T-01–T-08 is complete. Preserve the strict `make batch1-gate` contract and the four documented Batch 2 known failures. Do not begin Batch 2 or activate deferred modules without a new user assignment. The maintained reviewer suite is in review/; the user's exports/FABLE_REVIEW_RESPONSE script paths forward to it. Original reviewer scripts remain in review/original/.

The user has explicitly authorized Batch 2 after corrective C-01–C-06. The prior Batch-1 stop instruction is superseded. Preserve original independent review inputs. Require the corrective gate and a progressive Batch 2 gate; do not require known defects to remain failing after their fixes. No live actions or Batch 3 expansion are authorized.
