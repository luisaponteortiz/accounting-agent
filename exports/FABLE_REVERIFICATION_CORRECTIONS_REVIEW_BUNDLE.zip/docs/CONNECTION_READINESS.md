# Connection and release readiness

**Local fictional preparation only. G0 has not been accepted. No request to connect is pending.** Fable rejected the preceding checkpoint; the RV correction pass and explicit probe-setup adaptations are being returned for independent verification. Passing developer gates confers no new authority.

- [x] Shared scoped execution, persistent evidence/state and synthetic preparation workflows
- [x] C-01–C-06 and assigned Batch 2 controls, with RV correction source and regression evidence
- [x] Independent review inputs preserved; source and test changes exposed for review
- [ ] Fable acceptance of RV-01–RV-17 and the documented current-API probe adaptations
- [ ] Human G0 acceptance based on that independent verification
- [ ] Written actual client facts/policies/authority and authorization for approved G1 samples
- [ ] Accounting lead acceptance on a held-out client sample month
- [ ] Theresa's observed independent operation, teach-back and escalation effort
- [ ] Authenticated identity, scoped secrets, production persistence/worker, backups and restore
- [ ] Per-client provider capability and read-only integration scope/cost authorization
- [ ] Hosting, operational support and costs agreed with the relevant owners
- [ ] Real schedules, freshness and operating authority independently validated
- [ ] Write operations separately designed, verified and authorized; payments and final close remain reserved

## Synthetic evidence for review

The new teaching walkthrough keeps the original mismatched TX-009 receipt. Ten items receive independent preparation approval; TX-007, TX-009 and TX-011 remain blocked with recorded external referrals. October TX-008 and its receipt remain quarantined and named in package content. Package finalization and lock explicitly acknowledge those limits. Entry-impact totals and another client's December isolation are asserted through service operations without database edits. This is preparation handover, not a completed accounting close.

All original control assertions are exercised in the separate current-setup harness. The original full script still uses contracts deliberately rejected by RV-11/12/15; its incompatibilities, unchanged bytes and precise adapter delta are disclosed in docs/reverification/probe-adaptations.md. Human acceptance must not be inferred from a compatibility gate label.

Adapted RT14b now requires both initial decisions to succeed and D1 to be eligible before the new duplicate arrives. Fault regressions prove those starting conditions cannot silently fail. This strengthens review evidence and grants no additional operating authority.

Actual Bird Bowl legal entity, chart, accounting basis/framework, systems, recognition/FX/receipt policies, reviewer authority and source completeness remain unconfigured. Demo fact waivers and grants never become real client policy. No QBO, Desktop, bank/card, document or model adapter is connected. Deferred adapters are not implemented connectors.

Known further limits include atomic live-export consistency, external audit anchoring/WORM retention, production worker backoff/heartbeat, general currency minor units and actual identity/secret lifecycle. Live connectors, posting, payments, hosting and deployment require their own explicit authorization. No paid infrastructure or model call was incurred.
