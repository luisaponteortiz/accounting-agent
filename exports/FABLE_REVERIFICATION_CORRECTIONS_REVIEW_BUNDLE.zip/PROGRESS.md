# Accounting Agent OS — RV correction progress

**RV-01–RV-17 implemented; strengthened RT14b, all 136 tests and the combined gates pass. Independent Fable acceptance and G0 remain open.** Fable's 15 November review rejected C-01 on current source and Batch 2 despite the earlier developer gates passing. That review is preserved unchanged in exports/FABLE_REVERIFICATION/.

## Reproduction and order

Before source changes, the exact supplied command reproduced **21 OK / 11 WEAK / 3 NOTE**, exit 1, with all eleven named failures. The existing suite passed 111 tests. Evidence: docs/reverification/baseline-independent-probes.txt, baseline-independent-exit.txt and baseline-tests.txt. All 22 supplied files, prior independent inputs, and the historical archives have preservation hashes.

Implementation followed RV-04, RV-03, RV-01, RV-02, RV-05, RV-06, then RV-07–RV-13 and RV-14–RV-17. No Batch 3 capability or technology-stack replacement was introduced.

| Corrections | What executes | Regression evidence | Still unconnected / bounded |
| --- | --- | --- | --- |
| RV-04, RV-03, RV-01 | Idempotent receipt binding; latest-completed-run membership; removed-item history and superseded exceptions; lock-aware new-key supersession and supporting evidence; approval events | RT12b/c/d, RN02/RN02b; removal/finalization, source-move, scope/history and replay tests | Live feed semantics and automatic restoration after a replacement is voided remain unverified/deferred |
| RV-02 | Identity-based origin ownership across versions/supersession; stale origin-reference hold on journals | RT15; updated-reference and source-revision collisions | No ledger posting or subledger execution |
| RV-05, RV-06 | Independently approved effective rule retirement; typed new close configuration; legacy untyped requirements remain unsatisfied | RT09a/b/c, RT19a/b; historical retirement/reintroduction and bare-string refusal tests | Actual client mappings/checklist/authority remain unknown |
| RV-07–RV-10 | Activity/account-type constrained dispositions; duplicate candidate binding; truthful surviving-item path with disposition lineage; functional rule-author history | RT14a/b/c/e, RN05b; invalid cash/expense treatments, candidate arrival, exclusion/revocation and semantic-author tests | Actual recognition and fee/interest policy require client validation |
| RV-11 | Nonempty valid freshness, or explicitly reasoned no-evidence authority approved and audited; legacy empty mandates suspended | RT10a/b; malformed predicate/unknown kind/explicit reason checks; old recurrence regressions use stated authority | Live schedules remain disabled |
| RV-12 | Revised receipt/support history and mandatory independent acceptance; nonclearing receipt referrals | Revision/supplier refusal tests; original and corrected values remain visible | Document authenticity/OCR and real corrected-evidence policy unavailable |
| RV-13–RV-15 | Statement assurance limits and missing-prior/identity holds; explicit approved line-ID exception; alias preview/collision IDs; supporting evidence for each duplicate candidate | RT13/RT13n, RT09d, RT14d; frozen-prior-statement, explicit-rule and candidate-document tests | Manually supplied statements are not independently authenticated |
| RV-16, RV-17 | Complete runtime inventory including web assets; immutable package supersession with one displayed governing version | Static inventory comparison and package chain/frozen-byte tests | Full live export consistency/WORM audit remain Batch 3 |

Source/evidence/artifact/decision/package histories remain immutable. Migrations 13–14 add append-only retirement records and suspend legacy empty-freshness authority without rewriting accounting history. A follow-up regression fixed re-enqueue after disposition revocation: returning to earlier inputs creates a new execution projection and preserves the original artifact's rejection rather than reviving a stale run.

## Current gates and the compatibility boundary

The user requested that adapted RT14b fail unless both starting dispositions succeed and D1 is eligible before D3 arrives. Those assertions now execute in the generated adapter. Two added fault-injection tests confirm refusal of either starting decision or an ineligible D1 aborts the probe. The targeted strengthened probe, both tests, and all four rerun gates pass. The complete seven-probe explanation is in docs/reverification/probe-adaptations.md and is included in the rebuilt bundle. Prior release logs and the prior adapted script are preserved under docs/reverification/before-rt14b-strengthening/; rt14b-positive-preconditions.patch isolates this follow-up change. No application source/config/fixture/web file changed.

The exact original all-probe file remains unchanged. Three requested contracts invalidate seven original positive setups: empty freshness, missing duplicate-candidate support, and unreviewed revised evidence. The separately generated review/fable_reverification_probes.py changes only those setups and preserves all original verdict/gate expressions. Its final full run reports **35 OK**. The unmodified original compatible 28 probes report **28 OK**. make test passed **136 tests**, including the original 41 methods, both probe runs, preservation checks and new behavioral regressions; make reverification-gate and the unmodified historical corrective checkpoint passed. make check and make batch2-gate also passed. Final command logs are in docs/reverification/final-*-release.txt; all 60 case outcomes are in docs/batch2/final-validation.json.

Do not describe the unmodified full command against current code as passing. Its compatibility failures are recorded and explained in docs/reverification/probe-adaptations.md; the exact adapter delta is supplied for Fable to judge, as permitted in the corrective JSON. No expectation was changed to restore unsafe behavior. Existing Batch 2 cases must remain **29 PASS / 10 FIXED / 21 DEFERRED-OK**, with no unexpected status.

## Teaching month and boundary

The delivered service-only walkthrough now keeps TX-009's 79.99 receipt unchanged and refers the mismatch. It produces ten independent approvals and three held, explicitly dispositioned items: pending TX-007, receipt mismatch TX-009 and foreign TX-011. October TX-008 and its receipt remain named quarantined evidence. Two linked preparation handovers and a recorded lock acknowledge these holds; none becomes a clean accounting approval. Approved proposed-entry impact is office supplies +311.00, repairs +200.00, card liability −211.00 and cash −300.00, net zero. A second client's December workflow remains isolated.

The adapted independent RG0 additionally tests the revised_evidence_accepted route and retains its original eleven-approval assertions. See FABLE_RV_CORRECTIONS_HANDOFF.md and docs/REVERIFICATION_CORRECTIONS_REPORT.md for final results, changed files and review commands. The earlier Batch 2 report is historical, not current acceptance evidence.

No real client connection, model call, posting, payment, deployment, paid service or real sample use occurred. AP, AR, full reconciliation, reporting, general currency support, production identity/reliability, live export consistency and audit anchoring remain deferred. UC-1, UC-4 and UC-5 remain unverified concerns rather than claimed fixes. Human G0 acceptance and G1–G4 remain closed pending independent review and explicit authority.
