"""Ordered source lifecycle and scoped provenance; no connector operations."""
import json
from .core import ControlError, canonical, digest, instant, utcnow


class SourceControl:
    def source_revision(self,db,actor,source,packet):
        kind,key,value=source['kind'],source['key'],source['data']
        old=db.execute('SELECT s.*,h.removed FROM source_heads h JOIN snapshots s ON s.id=h.snapshot_id WHERE h.scope=? AND h.kind=? AND h.source_key=?',(actor.scope,kind,key)).fetchone()
        as_of=source.get('as_of')
        if type(as_of) is int and as_of>=0:order_type,order_value='sequence',str(as_of)
        elif isinstance(as_of,str):order_type,order_value='timestamp',instant(as_of).isoformat()
        elif as_of is None:order_type,order_value='legacy_arrival',utcnow()
        else:raise ControlError('Invalid source as_of')
        system=source.get('source_system',value.get('source_system','fixture'))
        if system!='fixture':raise ControlError('Only fictional source systems are enabled',403)
        removed=source.get('tombstone',False)
        if type(removed) is not bool:raise ControlError('Invalid tombstone')
        reason=source.get('removal_reason')
        if removed and reason not in ('feed_removed','voided','superseded'):raise ControlError('Removal reason required')
        supersedes=source.get('supersedes') or value.get('supersedes_source_id')
        predecessor=None
        if supersedes:
            old_key=supersedes if ':' in supersedes else value.get('account_id','')+':'+supersedes
            predecessor=db.execute('SELECT * FROM source_heads WHERE scope=? AND kind=? AND source_key=?',(actor.scope,kind,old_key)).fetchone()
            if old_key==key:raise ControlError('Supersession requires a different source identity')
        oldmeta=db.execute('SELECT * FROM source_metadata WHERE snapshot_id=?',(old['id'],)).fetchone() if old else None
        force=bool(old and int(removed)!=old['removed']) or bool(oldmeta and (oldmeta['order_type']!=order_type or oldmeta['as_of']!=order_value) and as_of is not None)
        if predecessor and not db.execute('SELECT 1 FROM source_links l JOIN snapshots n ON n.id=l.new_snapshot_id WHERE l.scope=? AND n.kind=? AND n.source_key=? AND l.old_snapshot_id=?',(actor.scope,kind,key,predecessor['snapshot_id'])).fetchone():force=True
        sid,is_new=self.store.snapshot(db,actor.scope,kind,key,value,actor.id,force_version=force)
        if not is_new:
            b=db.execute('SELECT * FROM source_periods WHERE snapshot_id=? ORDER BY id DESC LIMIT 1',(sid,)).fetchone()
            if b and not b['admitted'] and b['reason']=='UNASSIGNED_ACCOUNTING_PERIOD':self.bind_source(db,actor,sid,value,packet.get('period_id'))
            return sid,False
        accepted=True
        if oldmeta and order_type==oldmeta['order_type'] and order_type!='legacy_arrival':
            if (int(order_value)<int(oldmeta['as_of']) if order_type=='sequence' else order_value<oldmeta['as_of']):accepted=False
            if order_value==oldmeta['as_of'] and old['hash']!=digest(value):accepted=False
        elif oldmeta and order_type!=oldmeta['order_type'] and oldmeta['order_type']!='legacy_arrival':accepted=False
        db.execute('INSERT INTO source_metadata VALUES(?,?,?,?,?,?,?,?)',(sid,actor.scope,system,order_type,order_value,int(removed),reason,packet.get('period_id') or value.get('period_id')))
        if not accepted:
            self.store.audit(db,actor.scope,actor.id,'older_or_conflicting_source_retained',{'snapshot_id':sid,'governing_snapshot_id':old['id'] if old else None})
            return sid,False
        db.execute('INSERT INTO source_heads(scope,kind,source_key,snapshot_id,removed) VALUES(?,?,?,?,?) ON CONFLICT(scope,kind,source_key) DO UPDATE SET snapshot_id=excluded.snapshot_id,removed=excluded.removed',(actor.scope,kind,key,sid,int(removed)))
        if supersedes and not predecessor:
            self.accounting_event(db,actor,None,key,'SOURCE_SUPERSESSION_UNRESOLVED',{'snapshot_id':sid,'target_key':old_key})
        if predecessor:
            db.execute("INSERT INTO source_links(scope,old_snapshot_id,new_snapshot_id,reason,created) VALUES(?,?,?,'superseded',?)",(actor.scope,predecessor['snapshot_id'],sid,utcnow()))
            self.source_approval_events(db,actor,predecessor['source_key'],sid,'APPROVED_SOURCE_SUPERSEDED')
        self.bind_source(db,actor,sid,value,packet.get('period_id') or value.get('period_id'))
        if old and (old['hash']!=digest(value) or removed):
            self.source_approval_events(db,actor,key,sid,'APPROVED_SOURCE_REMOVED' if removed else 'APPROVED_SOURCE_REVISED')
        self.store.audit(db,actor.scope,actor.id,'source_revision_accepted',{'snapshot_id':sid,'source_key':key,'as_of':order_value,'ordering':order_type,'removed':removed,'reason':reason})
        return sid,True

    def supersession_link(self,db,scope,snapshot_id):
        return db.execute('SELECT l.* FROM source_links l JOIN snapshots n ON n.id=l.new_snapshot_id JOIN snapshots current ON current.id=? WHERE l.scope=? AND n.scope=? AND n.kind=current.kind AND n.source_key=current.source_key ORDER BY n.version DESC,l.id DESC LIMIT 1',(snapshot_id,scope,scope)).fetchone()

    def supersession_refs(self,db,scope,snapshot_id):
        result=[];seen=set()
        while snapshot_id not in seen:
            seen.add(snapshot_id);link=self.supersession_link(db,scope,snapshot_id)
            if not link:break
            row=db.execute('SELECT * FROM snapshots WHERE scope=? AND id=?',(scope,link['old_snapshot_id'])).fetchone()
            result.append({'snapshot_id':row['id'],'source_key':row['source_key'],'hash':row['hash'],'version':row['version'],'link_id':link['id']})
            snapshot_id=row['id']
        return result

    def evidence_revisions(self,db,scope,sources):
        result={}
        for source in sources:
            if source['kind'] not in ('receipt','document'):continue
            changes=[]
            for earlier in db.execute('SELECT * FROM snapshots WHERE scope=? AND kind=? AND source_key=? AND version<? ORDER BY version',(scope,source['kind'],source['source_key'],source['version'])):
                value=json.loads(earlier['payload']);fields=sorted(k for k in set(value)|set(source['value']) if value.get(k)!=source['value'].get(k))
                if not fields:continue
                changes.append({'source_key':source['source_key'],'earlier':{'snapshot_id':earlier['id'],'hash':earlier['hash'],'version':earlier['version'],'supplier':earlier['actor']},'current':{'snapshot_id':source['id'],'hash':source['hash'],'version':source['version'],'supplier':source['actor']},'changed_fields':fields,'supplier':source['actor']})
            if changes:result[source['source_key']]=changes
        return result

    def source_identity(self,db,scope,snapshot_id):
        row=db.execute('SELECT kind,source_key FROM snapshots WHERE scope=? AND id=?',(scope,snapshot_id)).fetchone()
        if not row:raise ControlError('Origin source outside client scope',403)
        ancestors=self.supersession_refs(db,scope,snapshot_id)
        return (row['kind'],ancestors[-1]['source_key'] if ancestors else row['source_key'])

    def apply_supersession(self,db,actor,snapshot_id):
        link=self.supersession_link(db,actor.scope,snapshot_id)
        if not link:return
        binding=db.execute('SELECT admitted FROM source_periods WHERE snapshot_id=? ORDER BY id DESC LIMIT 1',(snapshot_id,)).fetchone()
        if not binding or not binding['admitted']:return
        old=db.execute('SELECT * FROM snapshots WHERE scope=? AND id=?',(actor.scope,link['old_snapshot_id'])).fetchone()
        db.execute('UPDATE source_heads SET removed=1 WHERE scope=? AND kind=? AND source_key=?',(actor.scope,old['kind'],old['source_key']))
        if old['kind']=='transaction':
            value=json.loads(old['payload'])
            for receipt in self.store.latest(db,actor.scope,'receipt'):
                if receipt['value']['account_id']==value['account_id'] and receipt['value']['transaction_source_id']==value['source_id']:
                    db.execute("UPDATE source_heads SET removed=1 WHERE scope=? AND kind='receipt' AND source_key=?",(actor.scope,receipt['source_key']))

    def source_had_approval(self,db,scope,key,period_id):
        for a in db.execute('SELECT a.* FROM artifacts a JOIN runs r ON r.id=a.run_id WHERE a.scope=? AND r.period_id=?',(scope,period_id)):
            evidence=json.loads(a['payload']).get('data',{}).get('evidence',[])
            if a['item_key']==key or any(e.get('source_key')==key for e in evidence):
                if db.execute("SELECT 1 FROM decisions WHERE scope=? AND artifact_id=? AND decision IN ('approve','resolve_approve')",(scope,a['id'])).fetchone():return True
        return False

    def source_approval_events(self,db,actor,key,snapshot_id,code):
        for a in db.execute('SELECT a.*,r.period_id FROM artifacts a JOIN runs r ON r.id=a.run_id WHERE a.scope=?',(actor.scope,)).fetchall():
            evidence=json.loads(a['payload']).get('data',{}).get('evidence',[])
            if (a['item_key']==key or any(e.get('source_key')==key for e in evidence)) and db.execute("SELECT 1 FROM decisions WHERE scope=? AND artifact_id=? AND decision IN ('approve','resolve_approve')",(actor.scope,a['id'])).fetchone():
                self.accounting_event(db,actor,a['period_id'],a['item_key'],code,{'artifact_id':a['id'],'source_key':key,'snapshot_id':snapshot_id})

    def accounting_event(self,db,actor,period_id,item_key,code,value):
        db.execute('INSERT INTO accounting_events(scope,period_id,item_key,code,payload,actor,created) VALUES(?,?,?,?,?,?,?)',(actor.scope,period_id,item_key,code,canonical(value),actor.id,utcnow()))
